import React, { Component } from "react";
import ProjectCard from "../project/ProjectCard";
import Popup from "reactjs-popup";
import ProjectModal from "../project/ProjectModal";
import "../../styles/project.css";

class Projects extends Component {
  constructor(props) {
    super(props);
    this.state = {
      projects: [],
      isLoaded: false,
    };
  }
  //TODO: create a domain and a utility for fetch in order to use the rest api uri
  fetchProjects() {
    fetch("http://localhost:9000/project/read")
      .then((res) => res.json())
      .then((json) => {
        this.setState({
          isLoaded: true,
          projects: json,
        });
      });
  }
  componentDidMount() {
    this.fetchProjects();
  }
  state = {
    show: false,
  };
  showModal = (e) => {
    this.setState({
      show: !this.state.show,
    });
  };

  render() {
    var { isLoaded, projects } = this.state;
    return (
      <div>
        <h1>My Projects</h1>
        <p>Welcome to my portfolio of projects:</p>

        <Popup
          modal
          trigger={
            <button
              className="plus radius"
              onClick={(e) => {
                this.showModal(e);
              }}
            ></button>
          }
          closeOnDocumentClick
        >
          {(close) => (
            <ProjectModal
              close={close}
              refreshProjects={() => this.fetchProjects()}
            />
          )}
        </Popup>

        <div className="container">
          <div className="row">
            {projects.map((project, i) => (
              <ProjectCard
                refreshProjects={() => this.fetchProjects()}
                key={i}
                title={project.title}
                description={project.description}
                link={project.link}
                id={project._id}
                image={project.image}
              />
            ))}
          </div>
        </div>
      </div>
    );
  }
}
export default Projects;
