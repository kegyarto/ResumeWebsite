import React from 'react';
import {Document,Pag, pdfjs, Page} from "react-pdf";
import axios from 'axios'
import Pdf from 'react-pdf-js';

class Resume extends React.Component {
    state={file: null}
   onDragEnter = (e) => {
    e.preventDefault()
    
  }
  handleDrop = (e) => {
    e.preventDefault();
  let file = e.dataTransfer.files[0];
  this.setState({ file })
  }
  render() {
    let { file } = this.state
     let url = file && URL.createObjectURL(file)
  return (
    <div onDragOver = {this.onDragEnter} onDrop={this.handleDrop} >
      <p> *******************DRAG FILES HERE *******************</p>
      <Document file={url}> <Page pageNumber={1} /> </Document>
      
<iframe src= {url} width="1000" height="1000"/>
      </div>
  )
  }
}



export default Resume