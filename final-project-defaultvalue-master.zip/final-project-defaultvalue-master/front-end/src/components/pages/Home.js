import React,{Component} from 'react'
import {render} from 'react-dom'



class Home extends Component{
    constructor(){
        super()
        this.state = {
            isLoaded:false,
            user:null
        }
    }
    
    componentDidMount(){
        fetch("http://localhost:9000/")
        .then(res => res.json())
        .then(json => {
            this.setState({
                user: json,
                isLoaded:true
            });
        })
        .then(()=>{console.log(this.state.user)})
    }

    render (){
        return(
        <div>
            {this.state.isLoaded ? (
                <h1>{this.state.user.name}</h1>
            ):null}
                
            {this.state.isLoaded ? (
                <p>{this.state.user.description}</p>
            ):null}

            {this.state.isLoaded ? (
                <ol>
                    <li>{this.state.user.name}</li>
                </ol>
            ):null}
            <img src="http://localhost:9000/images/upload/profile.jpg"/>
        </div>
        )
    }
}

export default Home