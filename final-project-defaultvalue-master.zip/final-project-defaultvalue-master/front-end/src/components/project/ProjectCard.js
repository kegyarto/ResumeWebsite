import React, { Component } from "react";
import Img from 'react-image'
import axios from "axios";

class ProjectCard extends Component {
  constructor(props) {
    super(props);
    this.onDelete = this.onDelete.bind(this);
  }

  refreshProjects = () => {
    this.props.refreshProjects();
  };

  onDelete() {
    const { id } = this.props;
    axios
      .get("http://localhost:9000/project/delete/" + id)
      .then((response) => {
        this.refreshProjects();
      })
      .catch((error) => {
        console.log(error);
      });
  }

  render() {
    const { title, description, link, image } = this.props;

    let linkStr = "";
    if (link.length > 0) {
      linkStr = (
        <a href={link} className="card-link">
          Link
        </a>
      );
    }

    return (
      <div className="col-sm-4">
        <div className="card" style={{ width: "18rem" }}>
          {/* <img
            className="card-img-top"
            src={`http://localhost:9000/images/upload/${image}`}
            height="100"
            alt=""
          /> */}
<Img className="card-img-top"
    src={[`http://localhost:9000/images/upload/${image}`, 'http://localhost:9000/images/upload/default-app.png' ]}
  />
         {/*  */}

          <div className="card-body">
            <h5 className="card-title">{title}</h5>
            <p className="card-text">{description}</p>
          </div>
          <div className="card-body">
            {linkStr}
            <br />
            <br />
            <button
              className="btn btn-outline-danger"
              onClick={(e) => {
                if (
                  window.confirm(
                    "Are you sure you wish to delete this project?"
                  )
                )
                  this.onDelete(e);
              }}
            >
              Delete
            </button>
          </div>
        </div>
      </div>
    );
  }
}
export default ProjectCard;
