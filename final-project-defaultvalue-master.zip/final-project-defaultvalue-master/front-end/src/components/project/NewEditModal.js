import React from "react";
import axios from "axios";

import "../../styles/project.css";
export default class NewEditModal extends React.Component {
  constructor(props) {
    super(props);
    this.onSubmit = this.onSubmit.bind(this);

    this.state = {
      title: "",
      description: "",
      link: "",
      selectedFile: null
    };
  }

  fileSelectedHandler = event => {
    this.setState({
      selectedFile: event.target.files[0]
    });
  }

  fileUploadHandler = ()=>{


  }

  onClose = e => {
    this.props.onClose && this.props.onClose(e);
  };

  onSubmit(event) {
    event.preventDefault();

    var desc = this.descriptionInput.value;
    this.setState({description: desc});
    //this.setState({comment: 'Hello'});
    //this.state.description = desc;
    // this.state = {date: new Date()};
    // this.setState({
    //   date: new Date()
    // });

    const myFormData = new FormData();
    myFormData.append('myimage', this.state.selectedFile, this.state.selectedFile.name );
    
    axios
      .post("http://localhost:9000/project/create", this.state)
      .then(response => {
        console.log(response);
        this.onClose(event);
      })
      .catch(error => {
        console.log(error);
      });
  }

  changeHandler = e => {
    this.setState({ [e.target.name]: e.target.value });
  };

  render() {
    if (!this.props.show) {
      return null;
    }
    const { title, description, link } = this.state;
    return (
      <div class="modalView">
        <form onSubmit={this.onSubmit} class="form-group">
          <h2>{this.props.children}</h2>
          <div class="content">
            <label htmlFor="inputTitle">Title</label>
            <br />
            <input class="form-control"
              ref={titleInput => (this.titleInput = titleInput)}
              value={title}
              onChange={this.changeHandler}
              type="text"
              name="title"
              id="inputTitle"
              placeholder="Title"
              size="50"
            />
            <br />
            <label htmlFor="inputDescription">Descripcion: </label>
            <br />
            <textarea class="form-control"
              ref={descriptionInput =>
                (this.descriptionInput = descriptionInput)
              }
              onChange={this.changeHandler}
              placeholder="Description"
              id="inputDescription"
              rows="4"
              cols="50"
            >
            
            </textarea>
            <br />
            <label htmlFor="inputLink">Link</label>
            <br />
            <input class="form-control"
              ref={linkInput => (this.linkInput = linkInput)}
              value={link}
              onChange={this.changeHandler}
              type="text"
              name="link"
              id="inputLink"
              placeholder="Link"
              size="50"
            />
            <br />
            <label htmlFor="inputImage">Image: </label> <br />
            <input class="form-control-file" name="image" id="inputImage" type='file' onChange={this.fileSelectedHandler} multiple />
            <button class="btn btn-outline-secondary" onClick={this.fileUploadHandler}>Upload</button>
            <br />
          </div>
          <div class="actions">
            <br />
            <br />
            <button class="btn btn-outline-primary" >Save</button>
            &nbsp;&nbsp;&nbsp;
            <button
              class="btn btn-outline-secondary"
              onClick={e => {
                this.onClose(e);
              }}
            >
              Cancel
            </button>
            <br />
            <br />
          </div>
        </form>
      </div>
    );
  }
}
