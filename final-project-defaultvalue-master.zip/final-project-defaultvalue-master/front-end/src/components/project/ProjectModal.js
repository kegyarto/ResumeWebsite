import React from "react";
import axios from "axios";

export default class ProjectModal extends React.Component {
  constructor(props) {
    super(props);
    this.onSubmit = this.onSubmit.bind(this);

    this.state = {
      title: "",
      description: "",
      link: "",
      selectedFile: null,
    };
  }

  fileSelectedHandler = (event) => {
    this.setState({ selectedFile: event.target.files[0] });
  };

  refreshProjects = () => {
    this.props.refreshProjects();
  };

  onSubmit(event) {
    event.preventDefault();
    if (this.state.title === "" || this.state.description === "") {
      alert("Please enter required fields");
      return;
    }
    const fd = new FormData();
    fd.append("projectImage", this.state.selectedFile);
    fd.set("title", this.state.title);
    fd.set("description", this.state.description);
    fd.set("link", this.state.link);
    axios
      .post("http://localhost:9000/project/create", fd, {
        onUploadProgress: (progressEvent) => {
          console.log(
            "Upload Progress: " +
              Math.round((progressEvent.loaded / progressEvent.total) * 100) +
              "%"
          );
        },
      })
      .then((response) => {
        //Cleaning inputs
        this.setState({
          title: "",
          description: "",
          link: "",
          selectedFile: null,
        });
        this.refreshProjects();
        //TODO: Close
        this.onClose(event);
      })
      .catch((error) => {
        console.log("Error on Creating Project");
        console.log(error);
      });
  }
  changeHandler = (e) => {
    this.setState({ [e.target.name]: e.target.value });
  };
  onClose = (e) => {
    //e.preventDefault();
    this.props.onClose && this.props.onClose(e);
  };

  render() {
    const { title, description, link } = this.state;
    return (
      <div>
        <form onSubmit={this.onSubmit} className="form-group">
          <h2>{this.props.children}</h2>
          <div className="content">
            <label htmlFor="inputTitle">Title * :</label>
            <input
              className="form-control"
              ref={(titleInput) => (this.titleInput = titleInput)}
              value={title}
              onChange={this.changeHandler}
              type="text"
              name="title"
              id="inputTitle"
              placeholder="Title"
              size="50"
            />
            <br />

            <label htmlFor="inputDescription">Description * : </label>
            <input
              className="form-control"
              ref={(descriptionInput) =>
                (this.descriptionInput = descriptionInput)
              }
              value={description}
              onChange={this.changeHandler}
              type="text"
              name="description"
              id="inputDescription"
              placeholder="Description"
              size="300"
            />
            <br />

            <label htmlFor="inputLink">Link</label>
            <input
              className="form-control"
              ref={(linkInput) => (this.linkInput = linkInput)}
              value={link}
              onChange={this.changeHandler}
              type="text"
              name="link"
              id="inputLink"
              placeholder="http://"
              size="50"
            />
            <br />

            <label htmlFor="inputImage">Image: </label>
            <input
              className="form-control-file"
              name="image"
              id="inputImage"
              type="file"
              onChange={this.fileSelectedHandler}
              multiple
            />
            <br />
          </div>
          <div className="actions">
            <br />
            <br />
            <button className="btn btn-outline-primary">Save</button>
            &nbsp;&nbsp;&nbsp;
            <button
              className="btn btn-outline-secondary"
              onClick={(e) => {
                this.onClose(e);
              }}
            >
              Cancel
            </button>
            <br />
            <br />
          </div>
        </form>
      </div>
    );
  }
}
